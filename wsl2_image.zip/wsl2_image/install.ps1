[CmdletBinding()]
param (
    [Parameter(Mandatory=$true)]
    [string]$DistName,

    [Parameter(Mandatory=$true)]
    [string]$Path,

    [Parameter(Mandatory=$false)]
    [string]$Destination,

    [Parameter(Mandatory=$false)]
    [string]$Username = $env:Username
)

if ($Destination -eq "") {
    $Destination = "{0}\Packages\WSL.{1}\LocalState\rootfs" -f $env:LOCALAPPDATA, $DistName
}

New-Item -ItemType Directory -Force $Destination | Out-Null

Write-Output "Installing WSL distribution $DistName to $Destination from $Path..."
C:\Windows\System32\wsl.exe --import $DistName $Destination $Path
if ($LASTEXITCODE -ne 0) {
    throw "Failed installing WSL distribution, see error above. Canceling."
}
Write-Output "Installed WSL distribution."

Write-Output "Creating user..."
C:\Windows\System32\wsl.exe -d $DistName -u "root" -e sh -c "/usr/sbin/adduser --gecos '' $Username"
C:\Windows\System32\wsl.exe -d $DistName -u "root" -e sh -c "/usr/sbin/usermod -aG adm,sudo $Username"
C:\Windows\System32\wsl.exe -d $Distname -u "root" -e sh -c "/usr/bin/git config --file=/etc/wsl.conf user.default $Username"

Write-Output "Created user."

Write-Output "Stopping $DistName..."
C:\Windows\System32\wsl.exe --terminate $DistName
Write-Output "Stopped $DistName. Run ``wsl.exe -d $DistName`` to start it."
