# WSL image builder for Handelsbanken

## Usage
Install git for windows
Install Docker for windows or similair

Download the mingw-get.
Install it.
Add something like this C:\MinGW\bin to environment variables.
Launch (!important) git bash
Type mingw-get into the command line.
After type mingw-get install mingw32-make.
use mingw32-make to run make script

as PWSH admin run, so you can install image
Set-ExecutionPolicy Unrestricted

### Step 1: Build tar-ball

The tar-ball is an image of Ubuntu with packages and settings appropriate for Handelsbanken.
The tar-ball is appropriate for sharing and only needs to be built once and have a semi-convoluted build process requiring an existing WSL environment with Podman set up.

First, download the Ubuntu distribution of choice, currently Mantic 23.10 is recommended. Take note of the image digest from the second command.

```bash
podman pull artifactory.shbmain.shb.biz/docker-registry-1.docker.io/ubuntu:mantic
podman images artifactory.shbmain.shb.biz/docker-registry-1.docker.io/ubuntu:mantic -q
```

Ensure that `Containerfile` pulls from the image you just downloaded by setting its `FROM <digest>` line to match the image you downloaded.

The next step is to build the shbdev.tar file using make.
You can follow along in the logic by inspecting the `Makefile`, which builds the `Containerfile` which primarily calls the scripts in `scripts/<dir>/install.sh` in alphabetical order of the directory name.

```bash
make
```

Make creates an `out/shbdev.tar` asset that you can copy over to your Windows installation or a share or whereever.
Run `make clean` to remove the assets created by `make`.

```bash
cp out/shbdev.tar /mnt/c/Users/<YOUR USERNAME>/
make clean
```

You now have a distributable WSL image that can be imported using WSL.

### Step 2: Installing the image on Windows

> **Note:**
> If you're trying to run a PowerShell script from your `WSL` drive, you need to use `//wsl$/path/to/this/project` rather than `//wsl.localhost/path/...` or `//wsl/path/...`.
> Windows doesn't understand that the PowerShell script is stored locally for the latter options and might block the script from being run.

Pick a name for the installation, I've picked _OctagonalLinux_ for the demonstration below and run the `install.ps1` script with that name as your first argument and the path to the WSL tar-ball created in step 1 as your second argument. You'll be prompted for a new password for your user (which will be used by _sudo_ to install packages and such within your Linux installation).

```powershell
.\install.ps1 OctagonalLinux C:\Users\<YOUR USERNAME>\shbdev.tar
```

> **Optional arguments**
> _-Username_ Set your Linux username, by default it's the same as your Windows username.
> _-Destination_ Set the installation path for your virtual harddrive, by default this is deep in your LocalAppData directory.

Your WSL distribution is now ready and can be accessed using:

```powershell
wsl -d OctagonalLinux
```
