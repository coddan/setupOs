#!/usr/bin/env bash

set -exo pipefail


mkdir -p /etc/apt/keyrings
cp ./microsoft.gpg /etc/apt/keyrings/microsoft.gpg

# TODO: Replace jammy with `lsb_release -cs`, but Microsoft doesn't support Mavic.
echo "deb [arch=`dpkg --print-architecture` signed-by=/etc/apt/keyrings/microsoft.gpg] https://packages.microsoft.com/repos/azure-cli/ jammy main" > /etc/apt/sources.list.d/azure-cli.list

cp ./az.sh /usr/local/bin/az
