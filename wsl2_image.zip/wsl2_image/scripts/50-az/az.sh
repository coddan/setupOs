#!/usr/bin/env bash

set -eo pipefail

if [ -e /usr/bin/az ]; then
    /usr/bin/az "$@"
else
    echo "Azure CLI is not installed, install by running:"
    echo "    sudo apt install azure-cli"
    echo "Remove this script from /usr/local/bin/az if you believe this is an error,"
    echo "or if you'd like to use az provided from Windows."
fi
