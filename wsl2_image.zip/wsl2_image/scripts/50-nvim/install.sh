#!/usr/bin/env bash

set -exo pipefail
curl -LO "https://github.com/neovim/neovim/releases/download/v$NVIM_VERSION/nvim-linux64.tar.gz"
curl -L "https://github.com/folke/lazy.nvim/archive/refs/tags/v$NVIM_LAZY_VERSION.tar.gz" -o lazy.nvim.tar.gz
sha256sum -c shasums

mkdir -p /opt/nvim
mkdir -p /usr/local/share/nvim/lazy
mkdir -p /etc/skel/.config/nvim/lua/plugins

tar --extract --gunzip -f nvim-linux64.tar.gz && mv nvim-linux64 /opt/nvim
tar --extract --gunzip -f lazy.nvim.tar.gz
mv "lazy.nvim-$NVIM_LAZY_VERSION" /usr/local/share/nvim/lazy/lazy.nvim

git clone https://github.com/coddan/nvim.git
cp -rp ./nvim /etc/skel/.config/
echo "\n\n# Use neovim in place of vim\nalias vim='nvim'" >> /etc/skel/.bashrc
echo "\n\n# Use neovim in place of vi\nalias vi='nvim'" >> /etc/skel/.bashrc

