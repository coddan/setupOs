#!/usr/bin/env bash

set -exo pipefail

rm /etc/update-motd.d/50-motd-news /etc/update-motd.d/10-help-text
cp ./motd /etc/update-motd.d/20-shb
chmod +x /etc/update-motd.d/20-shb
