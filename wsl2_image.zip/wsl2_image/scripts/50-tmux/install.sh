#!/usr/bin/env bash

set -exo pipefail

git clone https://github.com/tmux-plugins/tpm /etc/skel/.tmux/plugins/tpm
sh /etc/skel/.tmux/plugins/tpm/tpm/bin/install_plugins
mv tmux.conf /etc/skel/.tmux.conf