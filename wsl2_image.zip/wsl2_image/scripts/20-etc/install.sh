#!/usr/bin/env bash

set -exo pipefail

cat ./bashrc_ext.sh >> /etc/bash.bashrc
cp ./wsl.conf /etc/wsl.conf
