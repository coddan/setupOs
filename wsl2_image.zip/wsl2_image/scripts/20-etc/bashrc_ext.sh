#!/usr/bin/env bash

export PATH="/opt/nvim/bin:$PATH"
export LC_ALL=C.UTF-8
export LANG=C.UTF-8
export REQUESTS_CA_BUNDLE="/etc/ssl/certs/ca-certificates.crt"

