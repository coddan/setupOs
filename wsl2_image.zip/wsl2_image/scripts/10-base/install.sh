#!/usr/bin/env bash

set -exo pipefail

apt-get update
apt-get -y upgrade
apt-get -y install adduser git sudo\
    apport binutils byobu curl dbus-x11 dirmngr\
    ed file git gnupg info libegl1 libgl1\
    libpam-systemd lsof man-db media-types patch\
    psmisc rsync software-properties-common time\
    wget wsl-setup show-motd command-not-found\
    bash-completion manpages openssh-client\
    podman cmake nodejs npm python-is-python3
apt-get -y clean

set +eo pipefail
yes | unminimize
